start-stop-daemon --stop --name ncdeamon
