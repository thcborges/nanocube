

# Check this assertion to avoid crashing server

Assertion failed: (min_address.level == max_address.level && min_address.x <= max_address.x && min_address.y <= max_address.y), function visitRange, file ../../src/QuadTree.hh, line 1142.